package com.example.calculate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
